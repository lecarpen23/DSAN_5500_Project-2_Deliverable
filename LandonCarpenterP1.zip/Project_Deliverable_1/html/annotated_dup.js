var annotated_dup =
[
    [ "project_deliverable_1", "namespaceproject__deliverable__1.html", [
      [ "ClassifierAlgotithm", "classproject__deliverable__1_1_1_classifier_algotithm.html", "classproject__deliverable__1_1_1_classifier_algotithm" ],
      [ "DataSet", "classproject__deliverable__1_1_1_data_set.html", "classproject__deliverable__1_1_1_data_set" ],
      [ "Experiment", "classproject__deliverable__1_1_1_experiment.html", "classproject__deliverable__1_1_1_experiment" ],
      [ "kdTreeKNNClassifier", "classproject__deliverable__1_1_1kd_tree_k_n_n_classifier.html", "classproject__deliverable__1_1_1kd_tree_k_n_n_classifier" ],
      [ "QualDataSet", "classproject__deliverable__1_1_1_qual_data_set.html", "classproject__deliverable__1_1_1_qual_data_set" ],
      [ "QuantDataSet", "classproject__deliverable__1_1_1_quant_data_set.html", "classproject__deliverable__1_1_1_quant_data_set" ],
      [ "simpleKNNClassifier", "classproject__deliverable__1_1_1simple_k_n_n_classifier.html", "classproject__deliverable__1_1_1simple_k_n_n_classifier" ],
      [ "TimeSeriesDataSet", "classproject__deliverable__1_1_1_time_series_data_set.html", "classproject__deliverable__1_1_1_time_series_data_set" ]
    ] ]
];