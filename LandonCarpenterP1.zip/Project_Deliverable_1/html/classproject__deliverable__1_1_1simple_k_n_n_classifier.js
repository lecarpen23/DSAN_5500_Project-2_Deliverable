var classproject__deliverable__1_1_1simple_k_n_n_classifier =
[
    [ "__init__", "classproject__deliverable__1_1_1simple_k_n_n_classifier.html#aa70736ab869c26df1e1891cd76989ace", null ]
];