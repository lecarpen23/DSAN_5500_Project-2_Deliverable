var classproject__deliverable__1_1_1_quant_data_set =
[
    [ "__init__", "classproject__deliverable__1_1_1_quant_data_set.html#adec2fd35371600347e0fcc91ba7481c0", null ]
];