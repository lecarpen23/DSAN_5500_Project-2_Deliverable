var classproject__deliverable__1_1_1_experiment =
[
    [ "__init__", "classproject__deliverable__1_1_1_experiment.html#a832ab0f1e390d6088fb2432d5358830a", null ],
    [ "runCrossVal", "classproject__deliverable__1_1_1_experiment.html#a398b6288fe7ff9eb8e7c8c086135e183", null ],
    [ "score", "classproject__deliverable__1_1_1_experiment.html#a0aa988e9fe5c6723b101fdb84157a6a9", null ]
];