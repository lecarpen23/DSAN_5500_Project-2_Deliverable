var classproject__deliverable__1_1_1_classifier_algotithm =
[
    [ "__init__", "classproject__deliverable__1_1_1_classifier_algotithm.html#a56be17c686e2c75c3fb103a492584036", null ],
    [ "test", "classproject__deliverable__1_1_1_classifier_algotithm.html#ad68ef59601d322c15da1980dda7f5404", null ],
    [ "train", "classproject__deliverable__1_1_1_classifier_algotithm.html#a13c25c450862da9ea563de3dcbdd2455", null ]
];