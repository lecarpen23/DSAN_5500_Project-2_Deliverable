var test_8py =
[
    [ "dataset", "test_8py.html#a7ae1f3b36ab0d5bcadda8670720512d6", null ],
    [ "experiment", "test_8py.html#ae4a6fdb41b4ffcb28c315d01868c9293", null ],
    [ "kd_tree_knn", "test_8py.html#a776dbf7ddc7324e65b12235fd19a1a20", null ],
    [ "qual_dataset", "test_8py.html#ab5c0d749f41f1f0f7b09fdd643551231", null ],
    [ "quant_dataset", "test_8py.html#a3dc471deb6f0d896e7d93656a2128d92", null ],
    [ "simple_knn", "test_8py.html#aea2a668d226200934c4654929acf76d8", null ],
    [ "ts_dataset", "test_8py.html#aa5599ac2810390c59a591141824f4959", null ]
];