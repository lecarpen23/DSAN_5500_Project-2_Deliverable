var searchData=
[
  ['score_0',['score',['../classproject__deliverable__1_1_1_experiment.html#a0aa988e9fe5c6723b101fdb84157a6a9',1,'project_deliverable_1::Experiment']]],
  ['simple_5fknn_1',['simple_knn',['../namespaceproject__deliverable__1.html#a7a0bf2221e0ceeb0c829ba55c621d3c9',1,'project_deliverable_1.simple_knn'],['../namespacetest.html#aea2a668d226200934c4654929acf76d8',1,'test.simple_knn']]],
  ['simpleknnclassifier_2',['simpleKNNClassifier',['../classproject__deliverable__1_1_1simple_k_n_n_classifier.html',1,'project_deliverable_1']]]
];
