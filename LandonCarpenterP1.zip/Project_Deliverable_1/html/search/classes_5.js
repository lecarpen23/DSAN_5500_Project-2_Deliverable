var searchData=
[
  ['simpleknnclassifier_0',['simpleKNNClassifier',['../classproject__deliverable__1_1_1simple_k_n_n_classifier.html',1,'project_deliverable_1']]]
];
