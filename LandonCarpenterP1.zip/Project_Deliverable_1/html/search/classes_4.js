var searchData=
[
  ['qualdataset_0',['QualDataSet',['../classproject__deliverable__1_1_1_qual_data_set.html',1,'project_deliverable_1']]],
  ['quantdataset_1',['QuantDataSet',['../classproject__deliverable__1_1_1_quant_data_set.html',1,'project_deliverable_1']]]
];
