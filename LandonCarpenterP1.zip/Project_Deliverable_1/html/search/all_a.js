var searchData=
[
  ['test_0',['test',['../namespacetest.html',1,'test'],['../classproject__deliverable__1_1_1_classifier_algotithm.html#ad68ef59601d322c15da1980dda7f5404',1,'project_deliverable_1.ClassifierAlgotithm.test()']]],
  ['test_2epy_1',['test.py',['../test_8py.html',1,'']]],
  ['timeseriesdataset_2',['TimeSeriesDataSet',['../classproject__deliverable__1_1_1_time_series_data_set.html',1,'project_deliverable_1']]],
  ['train_3',['train',['../classproject__deliverable__1_1_1_classifier_algotithm.html#a13c25c450862da9ea563de3dcbdd2455',1,'project_deliverable_1::ClassifierAlgotithm']]],
  ['ts_5fdataset_4',['ts_dataset',['../namespaceproject__deliverable__1.html#a52bf9156d42852b5918c13a01acb16b4',1,'project_deliverable_1.ts_dataset'],['../namespacetest.html#aa5599ac2810390c59a591141824f4959',1,'test.ts_dataset']]]
];
