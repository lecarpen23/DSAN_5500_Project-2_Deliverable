var searchData=
[
  ['simple_5fknn_0',['simple_knn',['../namespaceproject__deliverable__1.html#a7a0bf2221e0ceeb0c829ba55c621d3c9',1,'project_deliverable_1.simple_knn'],['../namespacetest.html#aea2a668d226200934c4654929acf76d8',1,'test.simple_knn']]]
];
