var searchData=
[
  ['test_0',['test',['../classproject__deliverable__1_1_1_classifier_algotithm.html#ad68ef59601d322c15da1980dda7f5404',1,'project_deliverable_1::ClassifierAlgotithm']]],
  ['train_1',['train',['../classproject__deliverable__1_1_1_classifier_algotithm.html#a13c25c450862da9ea563de3dcbdd2455',1,'project_deliverable_1::ClassifierAlgotithm']]]
];
