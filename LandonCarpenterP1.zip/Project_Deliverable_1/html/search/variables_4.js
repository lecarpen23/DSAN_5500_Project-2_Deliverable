var searchData=
[
  ['qual_5fdataset_0',['qual_dataset',['../namespaceproject__deliverable__1.html#a74c90db4fe4f25e062209b303d80f3ef',1,'project_deliverable_1.qual_dataset'],['../namespacetest.html#ab5c0d749f41f1f0f7b09fdd643551231',1,'test.qual_dataset']]],
  ['quant_5fdataset_1',['quant_dataset',['../namespaceproject__deliverable__1.html#aa7ee907cac69d5c14ad1d0dd1cc5e1cb',1,'project_deliverable_1.quant_dataset'],['../namespacetest.html#a3dc471deb6f0d896e7d93656a2128d92',1,'test.quant_dataset']]]
];
