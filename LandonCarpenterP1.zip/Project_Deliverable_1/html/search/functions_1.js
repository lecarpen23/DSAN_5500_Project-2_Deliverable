var searchData=
[
  ['clean_0',['clean',['../classproject__deliverable__1_1_1_data_set.html#a1fb86ea0f6ddfc52436803946c38dc1f',1,'project_deliverable_1::DataSet']]]
];
