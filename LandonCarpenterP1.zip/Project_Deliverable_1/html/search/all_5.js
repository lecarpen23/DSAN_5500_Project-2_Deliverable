var searchData=
[
  ['kd_5ftree_5fknn_0',['kd_tree_knn',['../namespaceproject__deliverable__1.html#a1ac243e4470f7488c3544ce9db9dfa5d',1,'project_deliverable_1.kd_tree_knn'],['../namespacetest.html#a776dbf7ddc7324e65b12235fd19a1a20',1,'test.kd_tree_knn']]],
  ['kdtreeknnclassifier_1',['kdTreeKNNClassifier',['../classproject__deliverable__1_1_1kd_tree_k_n_n_classifier.html',1,'project_deliverable_1']]]
];
