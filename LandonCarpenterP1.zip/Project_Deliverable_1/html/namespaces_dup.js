var namespaces_dup =
[
    [ "project_deliverable_1", "namespaceproject__deliverable__1.html", "namespaceproject__deliverable__1" ],
    [ "test", "namespacetest.html", [
      [ "dataset", "namespacetest.html#a7ae1f3b36ab0d5bcadda8670720512d6", null ],
      [ "experiment", "namespacetest.html#ae4a6fdb41b4ffcb28c315d01868c9293", null ],
      [ "kd_tree_knn", "namespacetest.html#a776dbf7ddc7324e65b12235fd19a1a20", null ],
      [ "qual_dataset", "namespacetest.html#ab5c0d749f41f1f0f7b09fdd643551231", null ],
      [ "quant_dataset", "namespacetest.html#a3dc471deb6f0d896e7d93656a2128d92", null ],
      [ "simple_knn", "namespacetest.html#aea2a668d226200934c4654929acf76d8", null ],
      [ "ts_dataset", "namespacetest.html#aa5599ac2810390c59a591141824f4959", null ]
    ] ]
];