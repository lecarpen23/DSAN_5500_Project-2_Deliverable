var namespaceproject__deliverable__1 =
[
    [ "ClassifierAlgotithm", "classproject__deliverable__1_1_1_classifier_algotithm.html", "classproject__deliverable__1_1_1_classifier_algotithm" ],
    [ "DataSet", "classproject__deliverable__1_1_1_data_set.html", "classproject__deliverable__1_1_1_data_set" ],
    [ "Experiment", "classproject__deliverable__1_1_1_experiment.html", "classproject__deliverable__1_1_1_experiment" ],
    [ "kdTreeKNNClassifier", "classproject__deliverable__1_1_1kd_tree_k_n_n_classifier.html", "classproject__deliverable__1_1_1kd_tree_k_n_n_classifier" ],
    [ "QualDataSet", "classproject__deliverable__1_1_1_qual_data_set.html", "classproject__deliverable__1_1_1_qual_data_set" ],
    [ "QuantDataSet", "classproject__deliverable__1_1_1_quant_data_set.html", "classproject__deliverable__1_1_1_quant_data_set" ],
    [ "simpleKNNClassifier", "classproject__deliverable__1_1_1simple_k_n_n_classifier.html", "classproject__deliverable__1_1_1simple_k_n_n_classifier" ],
    [ "TimeSeriesDataSet", "classproject__deliverable__1_1_1_time_series_data_set.html", "classproject__deliverable__1_1_1_time_series_data_set" ],
    [ "dataset", "namespaceproject__deliverable__1.html#ad9584e085cc8998e542a19eaec187308", null ],
    [ "experiment", "namespaceproject__deliverable__1.html#a52567df0f5fbb38f85357b37c111b6bc", null ],
    [ "kd_tree_knn", "namespaceproject__deliverable__1.html#a1ac243e4470f7488c3544ce9db9dfa5d", null ],
    [ "qual_dataset", "namespaceproject__deliverable__1.html#a74c90db4fe4f25e062209b303d80f3ef", null ],
    [ "quant_dataset", "namespaceproject__deliverable__1.html#aa7ee907cac69d5c14ad1d0dd1cc5e1cb", null ],
    [ "simple_knn", "namespaceproject__deliverable__1.html#a7a0bf2221e0ceeb0c829ba55c621d3c9", null ],
    [ "ts_dataset", "namespaceproject__deliverable__1.html#a52bf9156d42852b5918c13a01acb16b4", null ]
];