var hierarchy =
[
    [ "project_deliverable_1.ClassifierAlgotithm", "classproject__deliverable__1_1_1_classifier_algotithm.html", [
      [ "project_deliverable_1.kdTreeKNNClassifier", "classproject__deliverable__1_1_1kd_tree_k_n_n_classifier.html", null ],
      [ "project_deliverable_1.simpleKNNClassifier", "classproject__deliverable__1_1_1simple_k_n_n_classifier.html", null ]
    ] ],
    [ "project_deliverable_1.DataSet", "classproject__deliverable__1_1_1_data_set.html", [
      [ "project_deliverable_1.QualDataSet", "classproject__deliverable__1_1_1_qual_data_set.html", null ],
      [ "project_deliverable_1.QuantDataSet", "classproject__deliverable__1_1_1_quant_data_set.html", null ],
      [ "project_deliverable_1.TimeSeriesDataSet", "classproject__deliverable__1_1_1_time_series_data_set.html", null ]
    ] ],
    [ "project_deliverable_1.Experiment", "classproject__deliverable__1_1_1_experiment.html", null ]
];