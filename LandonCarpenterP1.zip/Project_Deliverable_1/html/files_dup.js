var files_dup =
[
    [ "project_deliverable_1.py", "project__deliverable__1_8py.html", "project__deliverable__1_8py" ],
    [ "test.py", "test_8py.html", "test_8py" ]
];